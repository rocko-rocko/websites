<?php
$a="aman0";
if(ord($a[4])==0)print "yes";
else print "no";
?>

